const http = require("http");

const fs = require("fs");

const server = http.createServer();

const mysql = require('mysql');

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
});

var loginData, loginMail, baseData;

con.query("CREATE DATABASE IF NOT EXISTS rgdb", (err, result) => {
    if (err) throw err;
    console.log('Database rgdb created');
});


con.query("use rgdb", (err, result) => {
    if (err) throw err;
    console.log("rgdb is using");
});


con.query('CREATE TABLE IF NOT EXISTS rgtab (id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), mail VARCHAR(255) UNIQUE, password VARCHAR(255))', (err, result) => {
    if (err) throw err;
    console.log("rgdb created");
    });


server.on("request", (req, res) =>{
    if (req.url == "/registration") {
       fs.readFile("index_registration.html", (err, data) => {
           if (err) throw err;
           res.writeHead(200, {"Content-Type":"text/html"});
           res.write(data);
           res.end();
       })
    }

    else if (req.url == "/login?") {
        fs.readFile("index_login.html", (err, data) => {
            if (err) throw err;
            res.writeHead(200, {"Content-Type":"text/html"});
            res.write(data);
            res.end();
        })
    }

    else if (req.url == "/usersregistration") {
        if (req.method == "POST") {
            res.writeHead(200, {"Content-Type":"text/plain"});
            req.on("data", (chunk) =>{
                console.log(JSON.parse(chunk));
                console.log("Registration data got on /usersregistration");

                var {firstName, lastName, mail, password} = JSON.parse(chunk);

                var regValue = [[firstName, lastName, mail, password]];

                var inserting = "INSERT INTO rgtab (firstName, lastName, mail, password) VALUES ?";

                con.query(inserting, [regValue], (err, result) => {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        console.log("data inserted");
                    }
                });
                res.end("Registration was succesfully");
            })
        }
    }

    else if (req.url == "/login/registered_users") {
        if (req.method == "POST") {
            req.on("data", (chunk) => {
                if ("delete" in JSON.parse(chunk)) {
                    var deleting = "DELETE FROM rgtab WHERE mail= ?";
                    var logValue = [loginMail];

                    con.query(deleting, [logValue], (err, result) => {
                        if (err) throw err;
                        console.log("Datas deleted");
                    })
                    res.end("Datas deleted");
                }
                else {
                var dataObj = JSON.parse(chunk);

                if (dataObj.firstName.length != 0 && dataObj.firstName != baseData[0].firstName) {
                    var settingName = (dataObj.firstName);
                    var wheringName = (baseData[0].id);

                    var sql = "UPDATE rgtab SET firstName= ? WHERE id =?";

                    con.query(sql, [settingName, wheringName], (err, result) => {
                        if (err) throw err;
                        console.log(result);
                    });
                }

                if (dataObj.lastName.length != 0 && dataObj.lastName != baseData[0].lastName) {
                    var settingSurname = (dataObj.lastName);
                    var wheringSurname = (baseData[0].id);

                    var sql1 = "UPDATE rgtab SET lastName= ? WHERE id = ?";

                    con.query(sql1, [settingSurname, wheringSurname], (err, result) => {
                        if (err) throw err;
                        console.log(result);
                    });
                }

                if (dataObj.mail.length != 0 && dataObj.mail != baseData[0].mail) {
                    var settingMail = (dataObj.mail);
                    var wheringMail = (baseData[0].id);

                    var sql2 = "UPDATE rgtab SET mail= ? WHERE id= ?";

                    con.query(sql2, [settingMail, wheringMail], (err, result) => {
                        if (err) throw err;
                        console.log(result);
                    });
                }

                if (dataObj.password.length != 0 && dataObj.password != baseData[0].password) {
                    var settingPassword = (dataObj.password);
                    var wheringPassword = (baseData[0].id);

                    var sql3 = "UPDATE rgtab SET password= ? WHERE id= ?";

                    con.query(sql3, [settingPassword, wheringPassword], (err, result) => {
                        if (err) throw err;
                        console.log(result);
                    });
                }


                res.end("Datas have changed")
            }

            })
        }
        else {
            var select = "SELECT * FROM rgtab WHERE mail = ?";

            var logValue = [loginMail];

            con.query(select, [logValue], (err, result) => {
                if (err) throw err;
                baseData = result;
            });

            con.query("SELECT * FROM rgtab", (err, result) => {
            if (err) throw err;
            var datas = [result, baseData];
            res.write(JSON.stringify(datas));
            res.end();
        });
        }
    }

    else if (req.url == "/login/users_table") {
        fs.readFile("users_table.html", (err, data) => {
            if (err) throw err;
            res.write(data);
            res.end();
        })
    }

    else if (req.url == "/") {
        if (req.method == "POST" && req.url == "/") {
            req.on("data", (chunk) => {
                loginData = JSON.parse(chunk);
                loginMail = loginData["mail"];

                //var sql = "SELECT * FROM rgtab WHERE mail = " + mysql.escape(loginMail);
                var sql = "SELECT * FROM rgtab WHERE mail = ?";

                var logValue = [loginMail];

                con.query(sql, [logValue], (err, result) => {
                    if (err) throw err;
                    baseData = result;
                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] == baseData[0].password)) {
                        res.end("Autorization was succesfully.");
                    }

                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] != baseData[0].password)) {
                        res.end("Wrong password. Please, type correct password.")
                    }

                    if (typeof(baseData[0]) == "undefined") {
                        res.end("There is no user with such as email.")
                    }
                })
            })
        }
        else {
            res.writeHead(200, {"Content-Type":"text/html"});
            fs.readFile("index.html", (err, data) => {
                if (err) throw err;
                res.write(data);
                res.end();
            });
        }
    }
}).listen(40000);

console.log("Server running on 40000");
