
* http://localhost:40000/registration   -------------   The page for registration.

* http://localhost:40000/login?   -------------------   The page for logining.
 
